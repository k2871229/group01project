package dao;

public interface CommentDAO {

}
