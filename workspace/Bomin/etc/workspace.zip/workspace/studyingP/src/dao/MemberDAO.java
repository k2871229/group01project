package dao;

import java.util.List;

import dto.MemberDTO;

public interface MemberDAO {

	//selectMem 활동회원검색
	public List<MemberDTO> selectMem(MemberDTO memberDto);
	//selectMemAll 탈퇴포함 전체회원검색
	public List<MemberDTO> selectMemAll(MemberDTO memberDto);
	//selectMemDel 탈퇴회원검색
	public List<MemberDTO> selectMemDel(MemberDTO memberDto);
	//selectMemCode 코드검색
	public MemberDTO selectMemCode(MemberDTO memberDto);
	//selectMemId 아이디검색
	public MemberDTO selectMemId(MemberDTO memberDto);
	//selectMemName 이름검색
	public MemberDTO selectMemName(MemberDTO memberDto);
	//selectMemAccess 권한검색
	public List<MemberDTO> selectMemAccess(MemberDTO memberDto);
	
	public void insertMember(MemberDTO memberDto);	//회원가입
	public void updateMember(MemberDTO memberDto);	//정보수정
	public void deleteMember(MemberDTO memberDto);	//탈퇴
	public void updateMemberAccess(MemberDTO memberDto); //권한변경
	
}