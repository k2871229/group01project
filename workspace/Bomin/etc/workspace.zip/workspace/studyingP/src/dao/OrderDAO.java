package dao;

public interface OrderDAO {

}
