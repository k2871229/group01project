package dao;

public interface ClassDAO {

}
