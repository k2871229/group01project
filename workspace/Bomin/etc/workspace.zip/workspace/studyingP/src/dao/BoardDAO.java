package dao;

public interface BoardDAO {

}
