package dto;

import java.sql.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class MemberDTO {

    private int mem_code = 0;
    private String mem_id = null;
    private String mem_pw = null; 
    private String mem_name = null;
    private String mem_phone = null;
    private String mem_email = null;
    private int mem_access = 0;
    private Date mem_date = null;
    private int mem_status = 0;
    
}